This is a pretty fun program isn't it.  You can vote if you liked it.
There is many ways to expand it to a more advanced auto-update/
live Update.  I have a program that has some cool autoupdate 
features (To give you an idea).

		www.sortabcme.com